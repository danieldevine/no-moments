var elem = document.getElementsByClassName("moments");
elem.remove();