window.addEventListener('load', function() {
  var elem = document.querySelector('.moments');
     elem.parentNode.removeChild(elem);
});